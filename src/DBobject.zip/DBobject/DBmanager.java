package DBobject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class DBmanager {
    private static final String URL = "jdbc:sqlite:sklad.db";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void initializeDatabase() {
        String sql = """
              CREATE TABLE IF NOT EXISTS Users (
                  user_id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  username TEXT NOT NULL UNIQUE,
                  password TEXT NOT NULL,
                  role TEXT NOT NULL,
                  name TEXT NOT NULL,
                  phone TEXT,
                  address TEXT,
                  registration_date TEXT NOT NULL
              );
              
              CREATE TABLE IF NOT EXISTS Products (
                  product_id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT NOT NULL,
                  description TEXT,
                  quantity INTEGER NOT NULL,
                  price REAL NOT NULL,
                  added_by INTEGER NOT NULL,
                  added_date TEXT NOT NULL,
                  modified_by INTEGER,
                  modified_date TEXT,
                  FOREIGN KEY (added_by) REFERENCES Users(user_id),
                  FOREIGN KEY (modified_by) REFERENCES Users(user_id)
              );
              
              CREATE TABLE IF NOT EXISTS Orders (
                  order_id INTEGER PRIMARY KEY AUTOINCREMENT,
                  client_id INTEGER NOT NULL,
                  order_date TEXT NOT NULL,
                  status TEXT NOT NULL,
                  FOREIGN KEY (client_id) REFERENCES Users(user_id)
              );
              
              CREATE TABLE IF NOT EXISTS Order_Items (
                  order_id INTEGER NOT NULL,
                  product_id INTEGER NOT NULL,
                  quantity INTEGER NOT NULL,
                  PRIMARY KEY (order_id, product_id),
                  FOREIGN KEY (order_id) REFERENCES Orders(order_id),
                  FOREIGN KEY (product_id) REFERENCES Products(product_id)
              );   
        """;

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()){
            stmt.execute(sql);
            System.out.println("Таблицы созданы или уже существуют");
        } catch (SQLException e) {
            System.out.println("Ошибка при создании таблицы: " + e.getMessage());
        }
    }
}
