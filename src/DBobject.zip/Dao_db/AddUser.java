package Dao_db;

import model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddUser {
    private Connection connection;

    public AddUser(Connection connection) {
        this.connection = connection;
    }

    public void addUser( User user) throws SQLException {
        String sql = "INSERT INTO Users (username, password, role, name, phone, address, registration_date) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)){
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getRole());
            stmt.setString(4, user.getName());
            stmt.setString(5, user.getPhone());
            stmt.setString(6, user.getAddress());
            stmt.setString(7, user.getRegistrationDate());
            stmt.executeUpdate();

        } catch (SQLException e) {

            System.out.println("Ошибка при добавление пользователя " + e.getMessage());
            throw  e;
        }
    }

}
