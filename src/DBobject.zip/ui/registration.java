package ui;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import Dao_db.AddUser;
import DBobject.DBmanager;
import model.User;

public class registration extends JFrame {
    private JTextField usernameField, nameField, phoneField, addressField;
    private JPasswordField passwordField;
    private JTextField roleField;
    private JButton registerButton;
    private AddUser userDao;

    public registration() {
        setTitle("Регистрация - Склад-Мастер");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        try {
            DBmanager.initializeDatabase();
            userDao = new AddUser(DBmanager.getConnection());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Ошибка подключения к базе данных: " + e.getMessage());
            System.exit(1);
        }

        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        inputPanel.add(new JLabel("Имя пользователя:"));
        usernameField = new JTextField(15);
        inputPanel.add(usernameField);

        inputPanel.add(new JLabel("Пароль:"));
        passwordField = new JPasswordField(15);
        inputPanel.add(passwordField);

        inputPanel.add(new JLabel("Роль (Client/Worker/Admin):"));
        roleField = new JTextField(15);
        inputPanel.add(roleField);

        inputPanel.add(new JLabel("Имя:"));
        nameField = new JTextField(15);
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Телефон:"));
        phoneField = new JTextField(15);
        inputPanel.add(phoneField);

        inputPanel.add(new JLabel("Адрес:"));
        addressField = new JTextField(15);
        inputPanel.add(addressField);

        registerButton = new JButton("Регистрация");
        registerButton.addActionListener(e -> registerUser());

        setLayout(new BorderLayout(10, 10));
        add(inputPanel, BorderLayout.CENTER);
        add(registerButton, BorderLayout.SOUTH);
    }

    private void registerUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String role = roleField.getText();
        String name = nameField.getText();
        String phone = phoneField.getText().isEmpty() ? null : phoneField.getText();
        String address = addressField.getText().isEmpty() ? null : addressField.getText();
        String registrationDate = "2025-05-01"; // ВРЕМЕННО - потом поменяю

        if (username.isEmpty() || password.isEmpty() || role.isEmpty() || name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Заполните все обязательные поля!");
            return;
        }

        User user = new User(0, username, password, role, name, phone, address, registrationDate);

        try {
            userDao.addUser(user);
            JOptionPane.showMessageDialog(this, "Регистрация успешна!");
            clearFields();
        } catch (SQLException e) {
            if (e.getMessage().contains("UNIQUE constraint failed")) {
                JOptionPane.showMessageDialog(this, "Пользователь с таким именем уже существует!");
            } else {
                JOptionPane.showMessageDialog(this, "Ошибка регистрации: " + e.getMessage());
            }
        }
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        roleField.setText("");
        nameField.setText("");
        phoneField.setText("");
        addressField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            registration window = new registration();
            window.setVisible(true);
        });
    }
}